using Exiled.Events.EventArgs;
using Exiled.API.Features;
using Exiled.API.Extensions;

namespace Spawnprotectdisable.Handlers
{
    class Player
    {
        public void OnShooting(ShootingEventArgs ev)
        {
            if (ev.Shooter.IsGodModeEnabled == true && ev.Shooter.Role != RoleType.Tutorial)
            {
                ev.Shooter.IsGodModeEnabled = false;
                Log.Info($"{ev.Shooter.Nickname} got godmode removed");
            }
        }
    }
}
